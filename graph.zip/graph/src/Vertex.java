package graph.src;
import java.awt.*;
public class Vertex{

	private int id;
	private Object info;
	private Color color;

	public Vertex(int id, Object info, Color color){
		this.id = id;
		this.info=info;
		this.color=color;
	}	

	public int getId(){

		return this.id;
	}
	public void setId(int id){

		this.id=id;
	}
	public Object getInfo(){
		return this.info;
	}
	public void setInfo(Object inf){
		this.info=inf;
	}
	public Color getColor(){
		return this.color;
	}
	public void setColor(Color couleur){
		this.color=couleur;
	}

	public String toString(){
		return "id: "+this.id+", info: "+this.info+", color: "+this.color;
	}

}