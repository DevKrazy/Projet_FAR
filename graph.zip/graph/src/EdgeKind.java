package graph.src;

public enum EdgeKind {
    directed,
    undirected;
}

