package graph.src;
import java.awt.*;

public abstract class Edge{

	private int id;
	private Color color;
	Vertex [] ends;
	private double value;

	public Edge(int id, Color color, double value) {
		this.id = id;
		this.color = color;
		this.ends = new Vertex[2];
		this.value = value;
	}

	public int getId(){

		return this.id;
	}
	public void setId(int id){

		this.id=id;
	}
	public Color getColor(){

		return this.color;
	}
	public void setColor(Color couleur){

		this.color=couleur;
	}

	public abstract Vertex[] getEnds();

	public void setEnds(Vertex v1, Vertex v2){
		this.ends[0]=v1;
		this.ends[1]=v2;
	}
	public void setEnds0(Vertex v1){

		this.ends[0]=v1;
	}

	public void setEnds1(Vertex v2){

		this.ends[1]=v2;
	}

	public double getValue(){

		return this.value;
	}

	public void setValue(double val){

		this.value=val;
	}

	public String toString(){
		return "id: "+this.id+", value: "+this.value+", color: "+this.color+" ends: "+this.ends[0]+ ", "+this.ends[1];
	}
}