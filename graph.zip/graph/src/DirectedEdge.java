package graph.src;

import java.awt.*;
public class DirectedEdge extends Edge {
	private int source;
    public DirectedEdge (int id, Color color, double value, int source){
        super(id,color,value);
        this.source = source;
    }

    @Override
    public Vertex[] getEnds() {
        return super.ends;
    }
    public Vertex getSource() {

        return getEnds()[this.source];
    }
    public Vertex getSink (){
        if (this.source == 0){
            return getEnds()[1];
        }else
            return getEnds()[0];
    }



    public String toString(){

        return super.toString()+" source: "+getSource();
    }
}

