package graph.src;

import java.awt.*;

public class TestGraph {
	public static void main(String[] args) {
		Vertex v = new Vertex(0, "premier", Color.BLACK);
		Vertex w = new Vertex(1, "deux", Color.blue);
		Edge e = new DirectedEdge(0, Color.LIGHT_GRAY, 456, 0);
		e.setEnds(v, w);
		System.out.println(e);
	}
}