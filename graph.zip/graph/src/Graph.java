package graph.src;

public interface Graph{

	int nbOfVertices();
	int nbOfEdges();
	void addVertex(Vertex v);
	void addEdge(Vertex v, Vertex w, EdgeKind ek);
	boolean isConnected();
	Edge[] getEdges(Vertex v, Vertex w);
	Edge[] getEdges();
	Vertex[] getVertices();
	Edge[] getNeighborEdges(Vertex v);	

}