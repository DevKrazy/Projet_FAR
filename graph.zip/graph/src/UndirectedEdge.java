package graph.src;

import java.awt.Color;
public class UndirectedEdge extends Edge {
    public UndirectedEdge(int id, Color color, double value) {
        super(id, color, value);
    }

    public Vertex[] getEnds() {
        return super.ends;
    }
   
}