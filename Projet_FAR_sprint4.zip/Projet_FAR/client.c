#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <dirent.h>
#include "utils/headers/utils.h"
#include "utils/headers/server_utils.h"

pthread_t msg_thread;
pthread_t file_thread;
sem_t file_semaphore;
char file_content[10000];
char fileName[1023];

/**
 * Configures the server's socket and updates the socket_return and addr_return values with the
 * created socket and the created address.
 * @param address the IPV4 address we want to use
 * @param port the port we want to use
 * @param socket_return the pointer where the created socket will be stored at
 * @param addr_return the address where the created sockaddr_in will be stored at
 * @return 0 if everything was successful; -1 if there was an error during socket creation
 */
int configure_server_socket(char* address, char* port, int* socket_return, struct sockaddr_in *addr_return) {

    // creates a socket in the IPV4 domain using TCP protocol
    int server_socket = socket(PF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Erreur lors de la création de la socket serveur pour les messages.\n");
        return -1;
    }
    printf("Socket serveur créée avec succès.\n");

    // server address configuration
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET; // address type
    inet_pton(AF_INET, address, &(server_address.sin_addr)); //converts the address from the CLI to the correct format
    server_address.sin_port = htons(atoi(port)); // address port (converted from the CLI)
    printf("Adresse du serveur configurée avec succès ! (%s:%s)\n", address, port);

    *socket_return = server_socket;
    *addr_return = server_address;
    return 0;
}

/**
 * Connects the given address to the given socket.
 * @param socket the server's socket
 * @param address the server's address (ip + port)
 * @return
 */
int connect_on(int socket, struct sockaddr_in address) {
    // connection to the server (message socket)
    socklen_t server_address_len = sizeof(struct sockaddr_in);
    int connect_res = connect(socket, (struct sockaddr*) &address, server_address_len); // opens the socket with the configured address
    if (connect_res == -1) {
        perror("Erreur lors de la connexion au serveur.\n");
        return -1;
    }
    printf("En attente de l'acceptation du serveur...\n");
    return 0;
}

void get_file_to_send() {
    // Demander à l'utilisateur quel fichier afficher
    DIR *dir_stream;
    struct dirent *dir_entry;
    dir_stream = opendir("./");
    if (dir_stream != NULL) {
        printf("Voilà la liste de fichiers :\n");
        while (dir_entry = readdir (dir_stream)) {
            if(strcmp(dir_entry->d_name, ".") != 0 && strcmp(dir_entry->d_name, "..") != 0) {
                // does not display the . and .. files
                printf("%s\n", dir_entry->d_name);
            }
        }
        (void) closedir(dir_stream);
    } else {
        perror ("Ne peux pas ouvrir le répertoire");
    }

    printf("Indiquer le nom du fichier : ");
    fgets(fileName, sizeof(fileName), stdin);
    fileName[strlen(fileName) - 1] = '\0';
    FILE *fps = fopen(fileName, "r");
    if (fps == NULL){
        printf("Ne peux pas ouvrir le fichier suivant : %s", fileName);
    } else {
        char str[1000];
        // Stores the file content
        while (fgets(str, 1000, fps) != NULL) {
            //printf("%s", str);
            strcat(file_content, str);
        }
        printf("contenu fichier : %s\n", file_content );
    }
    fclose(fps);
}

/**
 * The client's messaging thread.
 * @param socket the server's socket
 */
void* messaging_thread(void *socket) {
    char send_buffer[MAX_MSG_SIZE];
    int server_socket = (int) (long) socket;

    // gets and sends the client's name to the server
    printf("Entrez votre pseudo (max 10 lettres) : ");
    fgets(send_buffer, MAX_MSG_SIZE, stdin);
    send_buffer[strcspn(send_buffer, "\n")] = 0; // removes the \n at the end
    send(server_socket, send_buffer, MAX_MSG_SIZE, 0);
    printf("Bienvenue %s !\n", send_buffer);

    while (1) {
        fgets(send_buffer, MAX_MSG_SIZE, stdin);

        if (strcmp(send_buffer, "file\n") == 0) {
            // the client wants to send a file
            get_file_to_send();
            sem_post(&file_semaphore);
            printf("Fichier envoyé.\n");
        }

        else {
            // the client wants to send a message
            send(server_socket, send_buffer, MAX_MSG_SIZE, 0);
            printf("[Vous] : %s", send_buffer);
            }
        }
    }


/**
 * The client's file sending thread.
 * @param socket the server's socket
 */
void* file_sending_thread(void *socket) {
    int server_socket = (int) (long) socket;
    while (1) {
        sem_wait(&file_semaphore);
        int len = (int) strlen(file_content);
        send(server_socket, fileName, 1023, 0); // envoi du nom du fichier
        send(server_socket, &len, sizeof(int), 0); // envoi taille fichier
        send(server_socket, file_content, len, 0); // envoi du contenu du fichier
        printf("Fichier envoyé !\n");
        bzero(file_content, len);
    }
}


int  create_server_socket(char *argv[],int num_port) {
    // creates a socket in the IPV4 domain using TCP protocol
    int server_socket = socket(PF_INET, SOCK_STREAM, 0);
    check_error(server_socket, "Erreur lors de la création de la socket serveur.\n");
    printf("Socket serveur créée avec succès sur le port %d.\n",num_port);

    // server address configuration
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET; // address type
    inet_pton(AF_INET, argv[1], &(server_address.sin_addr)); //converts the address from the CLI to the correct format
    server_address.sin_port = htons(num_port); // address port (converted from the CLI)
    printf("Adresse du serveur configurée avec succès !\n");

    // connection to the server
    socklen_t server_address_len = sizeof(struct sockaddr_in);
    int connect_res = connect(server_socket, (struct sockaddr*) &server_address, server_address_len); // opens the socket with the configured address
    printf("En attente de l'acceptation du serveur...\n");
    check_error(connect_res, "Erreur lors de la connexion au serveur.\n");
    
    char msgServeur[MAX_MSG_SIZE];
    recv(server_socket, msgServeur, MAX_MSG_SIZE, 0);
    printf("%s\n", msgServeur );

    return server_socket;
}

int main(int argc, char *argv[]) {

    // checks for the correct args number
    if (argc != 3) {
        printf("Nombre d'arguments incorrect. Utilisation :\n");
        printf("%s <adresse_ip_serveur> <port>\n", argv[0]);
        exit(0);
    } else {
        printf("Lancement du client...\n");
    }


    /*
    // configures the server's file sending socket and connects to it
    int server_file_socket;
    struct sockaddr_in server_file_address;
    configure_server_socket(argv[1], argv[3], &server_file_socket, &server_file_address);
    connect_on(server_file_socket, server_file_address);

    // configures the server's message sending socket and connects to it
    int server_msg_socket;
    struct sockaddr_in server_msg_address;
    configure_server_socket(argv[1], argv[2], &server_msg_socket, &server_msg_address);
    connect_on(server_msg_socket, server_msg_address);
     */


    int server_file_socket = create_server_socket(argv,atoi(argv[2])+1);
    // send thread start

    pthread_create(&file_thread, NULL, file_sending_thread, (void *) (long) server_file_socket);

    int server_msg_socket = create_server_socket(argv,atoi(argv[2]));
    // send thread start
    pthread_create(&msg_thread, NULL, messaging_thread, (void *) (long) server_msg_socket);



    // receives the connection confirmation message from the server
    char recv_buffer[MAX_MSG_SIZE];
    recv(server_msg_socket, recv_buffer, MAX_MSG_SIZE, 0);
    printf("%s",recv_buffer );

    // starts the messaging thread

    // starts the file sending thread
    sem_init(&file_semaphore, PTHREAD_PROCESS_SHARED, 0);


    while (1) {
        int recv_res = recv(server_msg_socket, recv_buffer, MAX_MSG_SIZE, 0);
        printf("[Serveur] : %s\n", recv_buffer);
        if (recv_res == 0) {
            // the server closed the connection
            terminate_program(0);
        }
    }
}