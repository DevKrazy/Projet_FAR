# This script launches a client on the localhost address and the given port (first arg)
clear
./client 127.0.0.1 $1